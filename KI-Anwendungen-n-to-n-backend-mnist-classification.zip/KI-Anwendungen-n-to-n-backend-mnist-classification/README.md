# KI-Anwendungen-n-to-n-backend

Flask install: https://flask.palletsprojects.com/en/2.2.x/installation/
Flask quickstart: https://flask.palletsprojects.com/en/2.2.x/quickstart/
Check that the correct envierment is active.

Pythonanywhere (to deploy the backend): https://www.pythonanywhere.com/
